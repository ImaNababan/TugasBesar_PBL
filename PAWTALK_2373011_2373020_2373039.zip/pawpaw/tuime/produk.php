<?php
include 'koneksi.php'; // pastikan file ini berisi koneksi ke db

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Query untuk ambil data produk beserta nama kategori
$sql = "SELECT p.id_produk, p.nama_produk, p.harga_produk, p.stok, p.gambar, k.nama_kategori
        FROM produk p
        LEFT JOIN kategori k ON p.id_kategori = k.id_kategori
        ORDER BY p.id_produk ASC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Manajemen Produk - Petshop</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;600&display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Fredoka', sans-serif;
      background-color: #fffdfc;
      color: #333;
    }
    header {
      background-color: #f6b26b;
      color: white;
      padding: 1rem;
    }
    .btn-cute {
      background-color: #f9c784;
      border: none;
      color: #fff;
      border-radius: 20px;
      padding: 8px 16px;
      transition: 0.2s;
    }
    .btn-cute:hover {
      background-color: #f6b26b;
    }
    .table thead {
      background-color: #fff3e0;
    }
    .product-img {
      width: 80px;
      height: 80px;
      object-fit: cover;
      border-radius: 50%;
      align: center;
    }
  </style>
</head>
<body>

<header class="d-flex justify-content-between align-items-center">
  <h3><img src="assets/img/icons/sec.webp" width="40" class="me-2" alt="Icon">Manajemen Produk</h3>
  <a href="dashboard.php" class="btn btn-light">Kembali ke Dashboard</a>
</header>

<div class="container my-4">
  <div class="d-flex justify-content-between mb-3 flex-wrap gap-2">
    <a href="tambah.php" class="btn-cute">+ Tambah Produk</a>
    <input type="text" class="form-control" placeholder="Cari produk..." style="max-width: 300px;" id="searchInput">
  </div>

  <div class="table-responsive shadow-sm rounded">
    <table class="table align-middle table-bordered" id="produkTable">
      <thead>
        <tr>
          <th>#</th>
          <th>Gambar</th>
          <th>Nama Produk</th>
          <th>Kategori</th>
          <th>Harga</th>
          <th>Stok</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php
        if ($result->num_rows > 0) {
            $no = 1;
            while ($row = $result->fetch_assoc()) {
                $harga_formatted = number_format($row['harga_produk'], 0, ',', '.');
                echo "<tr>
                        <td>{$no}</td>
                        <td><img src='uploads/{$row['gambar']}' alt='Gambar Produk' class='product-img'></td>
                        <td>{$row['nama_produk']}</td>
                        <td>{$row['nama_kategori']}</td>
                        <td>Rp {$harga_formatted}</td>
                        <td>{$row['stok']}</td>
                        <td>
                          <a href='edit-produk.php?id={$row['id_produk']}' class='btn btn-sm btn-warning'>Edit</a>
                          <a href='hapus-produk.php?id={$row['id_produk']}' class='btn btn-sm btn-danger' onclick=\"return confirm('Yakin ingin menghapus produk ini?');\">Hapus</a>
                          <a href='detail_produk.php?id={$row['id_produk']}' class='btn btn-sm btn-info text-white'>Detail</a>
                        </td>
                      </tr>";
                $no++;
            }
        } else {
            echo "<tr><td colspan='7' class='text-center'>Data produk belum tersedia.</td></tr>";
        }
        $conn->close();
        ?>
      </tbody>
    </table>
  </div>
</div>

<footer class="text-center text-white py-3" style="background-color: #f6b26b;">
  &copy; 2025 Petshop Kita. Semua Hak Dilindungi.
</footer>

<script>
// Simple search/filter on table rows
document.getElementById('searchInput').addEventListener('keyup', function() {
  const filter = this.value.toLowerCase();
  const rows = document.querySelectorAll('#produkTable tbody tr');
  rows.forEach(row => {
    const text = row.textContent.toLowerCase();
    row.style.display = text.includes(filter) ? '' : 'none';
  });
});
</script>

</body>
</html>
