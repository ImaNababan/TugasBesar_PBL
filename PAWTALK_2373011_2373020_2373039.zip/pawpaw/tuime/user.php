<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manajemen Pengguna - Petshop</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Fredoka', sans-serif;
      background-color: #fffdfc;
    }
    header {
      background-color: #f6b26b;
      padding: 1rem;
      color: white;
    }
    .btn-cute {
      background-color: #ffc4e1;
      color: white;
      border: none;
      border-radius: 20px;
      padding: 8px 16px;
    }
    .btn-cute:hover {
      background-color: #f7a8cf;
    }
    .table thead {
      background-color: #fef3f9;
    }
    footer {
      background-color: #f6b26b;
      color: white;
    }
  </style>
</head>
<body>

<header class="d-flex justify-content-between align-items-center">
  <h3><img src="assets/img/icons/user-icon.png" width="40" class="me-2">Manajemen Pengguna</h3>
  <a href="dashboard.php" class="btn btn-light">Kembali ke Dashboard</a>
</header>

<div class="container my-4">
  <div class="d-flex justify-content-between mb-3 flex-wrap gap-2">
    <button class="btn-cute">+ Tambah Pengguna</button>
    <input type="text" class="form-control" placeholder="Cari pengguna..." style="max-width: 300px;">
  </div>

  <div class="table-responsive shadow-sm rounded">
    <table class="table align-middle table-bordered">
      <thead>
        <tr>
          <th>#</th>
          <th>Nama</th>
          <th>Email</th>
          <th>Role</th>
          <th>Status</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td>Andi Putra</td>
          <td>andi@petshop.com</td>
          <td>Admin</td>
          <td><span class="badge bg-success">Aktif</span></td>
          <td>
            <button class="btn btn-sm btn-warning">Edit</button>
            <button class="btn btn-sm btn-danger">Hapus</button>
          </td>
        </tr>
        <tr>
          <td>2</td>
          <td>Bella Sari</td>
          <td>bella@petshop.com</td>
          <td>Staf</td>
          <td><span class="badge bg-success">Aktif</span></td>
          <td>
            <button class="btn btn-sm btn-warning">Edit</button>
            <button class="btn btn-sm btn-danger">Hapus</button>
          </td>
        </tr>
        <tr>
          <td>3</td>
          <td>Charlie K.</td>
          <td>charlie@petshop.com</td>
          <td>Kasir</td>
          <td><span class="badge bg-secondary">Nonaktif</span></td>
          <td>
            <button class="btn btn-sm btn-warning">Edit</button>
            <button class="btn btn-sm btn-danger">Hapus</button>
          </td>
        </tr>
        <!-- Tambah lebih banyak dummy data jika diperlukan -->
      </tbody>
    </table>
  </div>
</div>

<footer class="text-center py-3">
  &copy; 2025 Petshop Kita. Semua Hak Dilindungi.
</footer>

</body>
</html>
