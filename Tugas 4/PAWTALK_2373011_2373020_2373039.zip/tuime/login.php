<?php
session_start();
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM pelanggan WHERE email = ?";
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $pelanggan = $result->fetch_assoc();

        if (password_verify($password, $pelanggan['password'])) {
            $_SESSION['id_pelanggan'] = $pelanggan['id_pelanggan'];
            $_SESSION['nama'] = $pelanggan['nama'];
            $_SESSION['username'] = $pelanggan['username'];

            header("Location: index.php");
            exit();
        } else {
            echo "<script>alert('Password salah!'); window.location.href='login-desain.php';</script>";
        }
    } else {
        echo "<script>alert('Email tidak ditemukan!'); window.location.href='login-desain.php';</script>";
    }
} else {
    header("Location: login-desain.php");
    exit();
}
?>
