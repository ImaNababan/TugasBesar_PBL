<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'];
    $username = $_POST['username']; 
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // pakai hash u/t keamanan

    // Cek apakah email atau username sudah terdaftar apa belum
    $cek = $koneksi->prepare("SELECT * FROM pelanggan WHERE email = ? OR username = ?");
    $cek->bind_param("ss", $email, $username);
    $cek->execute();
    $result = $cek->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Email atau Username sudah terdaftar!'); window.location.href='register-cust.php';</script>";
        exit;
    }

    $stmt = $koneksi->prepare("INSERT INTO pelanggan (nama, username, email, password) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nama, $username, $email, $password);

    if ($stmt->execute()) {
        echo "<script>alert('Registrasi berhasil! Silakan login.'); window.location.href='login-desain.php';</script>";
    } else {
        echo "<script>alert('Registrasi gagal!'); window.location.href='register-cust.php';</script>";
    }
}
?>
