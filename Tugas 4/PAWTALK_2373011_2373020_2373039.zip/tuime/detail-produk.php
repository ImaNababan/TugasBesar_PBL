<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Detail Stok Produk - Petshop Kita</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Fredoka', sans-serif;
      background-color: #fffaf5;
      color: #333;
    }
    header {
      background-color: #f6b26b;
      color: white;
      padding: 1rem;
    }
    .card {
      border-radius: 20px;
    }
    .section-title {
      font-size: 1.25rem;
      font-weight: 600;
      color: #f57c00;
      margin-bottom: 1rem;
    }
    .label {
      font-weight: bold;
      color: #555;
    }
    .value {
      color: #444;
    }
    .back-btn {
      background-color: #f9c784;
      color: white;
      border: none;
      border-radius: 20px;
      padding: 8px 16px;
    }
    .back-btn:hover {
      background-color: #f6b26b;
    }
    .product-img-large {
      width: 100%;
      max-width: 300px;
      border-radius: 20px;
      object-fit: cover;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      margin-bottom: 1.5rem;
    }
  </style>
</head>
<body>

<header class="d-flex justify-content-between align-items-center">
  <h3><img src="assets/img/icons/box.webp" width="40" class="me-2">Detail Stok Produk</h3>
  <a href="produk.php" class="back-btn">← Kembali</a>
</header>

<div class="container my-4">
  <div class="card p-4 shadow-sm text-center">
    <!-- Gambar Produk -->
    <img src="assets/img/icons/canin.jpeg" alt="Royal Canin Kitten" class="product-img-large mx-auto">

    <div class="section-title text-start">Informasi Produk</div>
    <div class="row mb-3 text-start">
      <div class="col-md-6">
        <p><span class="label">ID Produk:</span> <span class="value">PRD001</span></p>
        <p><span class="label">Nama Produk:</span> <span class="value">Royal Canin Kitten</span></p>
        <p><span class="label">Kategori:</span> <span class="value">Makanan Kucing</span></p>
        <p><span class="label">Stok Tersedia:</span> <span class="value">80</span></p>
      </div>
      <div class="col-md-6">
        <p><span class="label">Harga:</span> <span class="value">Rp 250.000</span></p>
        <p><span class="label">Lokasi Penyimpanan:</span> <span class="value">Gudang 1 - Rak A3</span></p>
        <p><span class="label">Tanggal Update Stok:</span> <span class="value">07 April 2025</span></p>
      </div>
    </div>

    <div class="section-title text-start">Deskripsi Produk</div>
    <p class="text-start">
      Royal Canin Kitten adalah makanan kucing premium yang diformulasikan khusus untuk anak kucing berusia 2–12 bulan. Produk ini kaya akan protein, vitamin, dan mineral yang penting untuk pertumbuhan sehat dan imunitas optimal. Tekstur dan rasa disesuaikan agar disukai anak kucing, serta mendukung kesehatan pencernaan dan bulu.
    </p>
  </div>
</div>

<footer class="text-center text-white py-3" style="background-color: #f6b26b;">
  &copy; 2025 Petshop Kita. Semua Hak Dilindungi.
</footer>

</body>
</html>
