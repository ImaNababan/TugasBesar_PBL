<?php
include 'koneksi.php';

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $namaProduk = $conn->real_escape_string($_POST['namaProduk']);
    $kategori = (int)$_POST['kategori'];
    $harga = (int)$_POST['harga'];
    $stok = (int)$_POST['stok'];
    $deskripsi = $conn->real_escape_string($_POST['deskripsi']);

    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['gambar']['tmp_name'];
        $fileName = $_FILES['gambar']['name'];
        $fileSize = $_FILES['gambar']['size'];
        $fileType = $_FILES['gambar']['type'];
        $allowedExtensions = ['jpg', 'jpeg', 'png'];
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        if (in_array($fileExtension, $allowedExtensions)) {
            // Buat folder baru untuk nyimpen foto
            $uploadDir = 'uploads/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            $newFileName = uniqid('img_') . '.' . $fileExtension;
            $destPath = $uploadDir . $newFileName;

            if (move_uploaded_file($fileTmpPath, $destPath)) {
                $tanggal_update = date('Y-m-d');
                $sql = "INSERT INTO produk (nama_produk, id_kategori, harga_produk, stok, deskripsi, gambar, tanggal_update)
                        VALUES ('$namaProduk', $kategori, $harga, $stok, '$deskripsi', '$newFileName', '$tanggal_update')";
            if ($conn->query($sql) === TRUE) {
                echo "<script>
                    alert('Produk berhasil disimpan.');
                    window.location.href = 'tambah.php';
                </script>";
                exit;
            } else {
                echo "Error saat menyimpan produk: " . $conn->error;
                unlink($destPath);
            }

            } else {
                echo "Gagal mengupload file gambar.";
            }
        } else {
            echo "Format file tidak valid. Hanya jpg, jpeg, dan png yang diperbolehkan.";
        }
    } else {
        echo "File gambar belum dipilih atau ada error saat upload.";
    }
} else {
    echo "Metode request tidak valid.";
}

$conn->close();
?>
