<?php
include 'koneksi.php';

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// ambil data kategori dari tabel kategori
$sql = "SELECT id_kategori, nama_kategori FROM kategori ORDER BY nama_kategori ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Tambah Produk - Petshop</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Fredoka', sans-serif;
      background-color: #fffaf3;
    }
    header {
      background-color: #f6b26b;
      color: white;
      padding: 1rem;
    }
    .btn-cute {
      background-color: #f9c784;
      border: none;
      color: #fff;
      border-radius: 20px;
      padding: 8px 16px;
    }
    .btn-cute:hover {
      background-color: #f6b26b;
    }
    .form-label {
      font-weight: 600;
    }
    .form-container {
      background: #fff;
      border-radius: 20px;
      padding: 2rem;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>

<header class="d-flex justify-content-between align-items-center">
  <h3><img src="assets/img/icons/sec.webp" width="40" class="me-2">Tambah Produk</h3>
  <a href="produk.php" class="btn btn-light">Kembali</a>
</header>

<div class="container my-5">
  <div class="form-container mx-auto" style="max-width: 700px;">
    <form action="tambah-produk.php" method="POST" enctype="multipart/form-data">
      <div class="mb-3">
        <label for="namaProduk" class="form-label">Nama Produk</label>
        <input type="text" class="form-control" id="namaProduk" name="namaProduk" placeholder="Contoh: Shampoo Kucing Soft Fur" required>
      </div>

      <div class="mb-3">
        <label for="kategori" class="form-label">Kategori</label>
        <select class="form-select" id="kategori" name="kategori" required>
          <option selected disabled>Pilih kategori</option>
          <?php
          if ($result->num_rows > 0) {
              while($row = $result->fetch_assoc()) {
                  echo '<option value="' . $row['id_kategori'] . '">' . htmlspecialchars($row['nama_kategori']) . '</option>';
              }
          } else {
              echo '<option disabled>Tidak ada kategori</option>';
          }
          ?>
        </select>
      </div>

      <div class="row">
        <div class="col-md-6 mb-3">
          <label for="harga" class="form-label">Harga (Rp)</label>
          <input type="number" class="form-control" id="harga" name="harga" placeholder="Contoh: 50000" required>
        </div>
        <div class="col-md-6 mb-3">
          <label for="stok" class="form-label">Stok</label>
          <input type="number" class="form-control" id="stok" name="stok" placeholder="Contoh: 100" required>
        </div>
      </div>

      <div class="mb-3">
        <label for="deskripsi" class="form-label">Deskripsi</label>
        <textarea class="form-control" id="deskripsi" name="deskripsi" rows="4" placeholder="Deskripsikan produk secara singkat dan menarik..." required></textarea>
      </div>

      <div class="mb-3">
        <label for="gambar" class="form-label">Upload Gambar</label>
        <input class="form-control" type="file" id="gambar" name="gambar" required>
      </div>

      <button type="submit" class="btn-cute">Simpan Produk</button>
    </form>
  </div>
</div>

<footer class="text-center text-white py-3" style="background-color: #f6b26b;">
  &copy; 2025 Petshop Kita. Semua Hak Dilindungi.
</footer>

</body>
</html>

<?php
$conn->close();
?>