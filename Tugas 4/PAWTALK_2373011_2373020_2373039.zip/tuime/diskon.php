<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Promo & Diskon - Petshop</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Fredoka', sans-serif;
      background-color: #fffdfc;
      color: #333;
    }
    header {
      background-color: #f6b26b;
      color: white;
      padding: 1rem;
    }
    .btn-cute {
      background-color: #f9c784;
      border: none;
      color: #fff;
      border-radius: 20px;
      padding: 8px 16px;
      transition: 0.2s;
    }
    .btn-cute:hover {
      background-color: #f6b26b;
    }
    .badge-pill {
      border-radius: 50px;
    }
    .promo-card {
      background-color: #fff8e1;
      border-radius: 16px;
      padding: 1rem 1.5rem;
      margin-bottom: 1rem;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }
    .promo-title {
      font-weight: 600;
      font-size: 1.2rem;
    }
    .promo-code {
      font-family: monospace;
      background-color: #ffe0b2;
      padding: 2px 8px;
      border-radius: 8px;
      font-size: 0.95rem;
    }
  </style>
</head>
<body>

<header class="d-flex justify-content-between align-items-center">
  <h3><img src="assets/img/icons/sec.webp" width="40" class="me-2">Promo & Diskon</h3>
  <a href="dashboard.php" class="btn btn-light">Kembali ke Dashboard</a>
</header>

<div class="container my-4">
  <h4 class="mb-3">Daftar Diskon Tersedia</h4>

  <!-- Promo 1 -->
  <div class="promo-card">
    <div class="d-flex justify-content-between flex-wrap align-items-center">
      <div>
        <div class="promo-title">Diskon Gajian Pet Lovers</div>
        <div>Potongan <strong>25%</strong> hingga <strong>Rp 50.000</strong></div>
        <div class="text-muted">Minimum Belanja: Rp 200.000</div>
        <div class="mt-1">Kode Promo: <span class="promo-code">GAJIPET25</span></div>
      </div>
      <div class="text-end">
        <div><span class="badge bg-success badge-pill">Dipakai: 120x</span></div>
        <div><span class="badge bg-secondary badge-pill">Sisa: 80</span></div>
      </div>
    </div>
  </div>

  <!-- Promo 2 -->
  <div class="promo-card">
    <div class="d-flex justify-content-between flex-wrap align-items-center">
      <div>
        <div class="promo-title">Diskon Awal Bulan</div>
        <div>Potongan <strong>10%</strong> hingga <strong>Rp 20.000</strong></div>
        <div class="text-muted">Minimum Belanja: Rp 100.000</div>
        <div class="mt-1">Kode Promo: <span class="promo-code">AWALBULAN10</span></div>
      </div>
      <div class="text-end">
        <div><span class="badge bg-success badge-pill">Dipakai: 200x</span></div>
        <div><span class="badge bg-secondary badge-pill">Sisa: 300</span></div>
      </div>
    </div>
  </div>

  <!-- Promo 3 -->
  <div class="promo-card">
    <div class="d-flex justify-content-between flex-wrap align-items-center">
      <div>
        <div class="promo-title">Flash Sale Vitamin</div>
        <div>Diskon <strong>Rp 15.000</strong> langsung</div>
        <div class="text-muted">Minimum Belanja: Rp 100.000</div>
        <div class="mt-1">Kode Promo: <span class="promo-code">VITFLASH15</span></div>
      </div>
      <div class="text-end">
        <div><span class="badge bg-success badge-pill">Dipakai: 60x</span></div>
        <div><span class="badge bg-secondary badge-pill">Sisa: 40</span></div>
      </div>
    </div>
  </div>

</div>

<footer class="text-center text-white py-3" style="background-color: #f6b26b;">
  &copy; 2025 Petshop Kita. Semua Hak Dilindungi.
</footer>

</body>
</html>
