<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Petshop Admin - Dashboard Penjualan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;600&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">

  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body {
      font-family: 'Fredoka', sans-serif;
      background-color: #fffdfc;
      color: #333;
    }
    header {
      background-color: #f6b26b;
      color: #fff;
    }
    .card {
      border-radius: 16px;
    }
    .card h6 {
      color: #666;
    }
    .badge-status {
      padding: 5px 10px;
      border-radius: 20px;
      font-size: 0.85rem;
    }
    .bg-paw {
      background-image: url('assets/img/bg-paw.png');
      background-repeat: repeat;
      background-size: 60px;
    }
    .pet-icon {
      width: 24px;
      margin-right: 5px;
    }
    .section-title {
      font-weight: 600;
      font-size: 1.25rem;
      margin-bottom: 1rem;
    }
    .topbar {
      background-color: #fff3e0;
      padding: 10px 20px;
      border-bottom: 1px solid #ffe0b2;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
    }
    .topbar .welcome-msg img {
      width: 36px;
      margin-right: 10px;
    }
    .topbar .icon-btn {
      background: none;
      border: none;
      margin-left: 10px;
      font-size: 1.2rem;
    }
    footer {
      background-color: #f6b26b;
      color: #fff;
      padding: 20px 0;
    }
    .table th, .table td {
      vertical-align: middle;
    }

    .list-group-item:hover {
      background-color: #fff7ec;
      transition: 0.3s ease;
      cursor: pointer;
    }
    
    .sidebar {
  width: 220px;
  min-height: 100vh;
  background-color: #fff8ef;
  border-right: 1px solid #f0d5b3;
  padding: 20px;
}

.sidebar h5 {
  text-align: center;
  color: #f6b26b;
  font-weight: 600;
  margin-bottom: 30px;
}

.sidebar .nav-link {
  color: #5a5a5a;
  padding: 10px 15px;
  border-radius: 10px;
  margin-bottom: 8px;
  font-size: 15px;
  display: flex;
  align-items: center;
}

.sidebar .nav-link i {
  color: #f6b26b;
  margin-right: 10px;
}

.sidebar .nav-link:hover,
.sidebar .nav-link.active {
  background-color: #fff0dc;
  color: #333;
  font-weight: 600;
}

  </style>
</head>
<body class="bg-paw">
  <div class="d-flex">
    <nav class="sidebar">
  <h5>🐾 Admin Menu</h5>
  <ul class="nav flex-column">
    <li class="nav-item">
      <a class="nav-link active" href="dashboard.php"><i class="fa fa-home"></i>Dashboard</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="user.php"><i class="fa fa-user"></i>Pengguna</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="diskon.php"><i class="fa fa-percent"></i>Diskon</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="produk.php"><i class="fa fa-box"></i>Produk</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="pesanan.php"><i class="fa fa-shopping-cart"></i>Pesanan</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#"><i class="fa fa-chart-bar"></i>Laporan</a>
    </li>
    <li class="nav-item">
      <a class="nav-link text-danger" href="logout.php"><i class="fa fa-sign-out-alt"></i>Logout</a>
    </li>
  </ul>
</nav>


  <div class="flex-grow-1">

  <header class="py-3">
    <div class="container d-flex justify-content-between align-items-center">
      <h3><img src="assets/img/icons/sec.webp" width="40" class="me-2">Dashboard Penjualan</h3>
      <a href="#" class="btn btn-light">Keluar</a>
    </div>
  </header>

  <div class="topbar">
    <div class="welcome-msg d-flex align-items-center">
      <img src="assets/img/icons/7.png" alt="Paw">
      <strong>Selamat datang kembali, Admin!</strong>
    </div>
    <div class="d-flex align-items-center">
      <input type="text" class="form-control me-2" placeholder="Cari produk atau pesanan..." style="max-width: 250px;">
      <button class="icon-btn" title="Notifikasi">🔔</button>
      <button class="icon-btn" title="Pesan Masuk">💬</button>
    </div>
  </div>
  
  <main class="container mt-4">
    <div class="row g-4 mb-4">
      <div class="col-md-3">
        <div class="card shadow-sm text-center p-3">
          <h6>Total Produk</h6>
          <img src="assets/img/icons/f3.webp" class="pet-icon">
          <h4>320</h4>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card shadow-sm text-center p-3">
          <h6>Pesanan Hari Ini</h6>
          <img src="assets/img/icons/f1.webp" class="pet-icon">
          <h4>27</h4>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card shadow-sm text-center p-3">
          <h6>Total Penjualan</h6>
          <img src="assets/img/icons/f2.webp" class="pet-icon">
          <h4>Rp 12.500.000</h4>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card shadow-sm text-center p-3">
          <h6>Stok Hampir Habis</h6>
          <img src="assets/img/icons/chart.png" class="pet-icon">
          <h4>8 Produk</h4>
        </div>
      </div>
    </div>

<!-- Grafik -->
<div class="row g-4 mb-4">
  <div class="col-lg-8">
    <div class="card shadow-sm p-4" style="height: 400px;">
      <div class="section-title">Grafik Penjualan Minggu Ini</div>
      <canvas id="salesChart" style="height: 100%;"></canvas>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card shadow-sm p-4" style="height: 400px;">
      <div class="section-title">Penjualan per Kategori</div>
      <canvas id="categoryChart" style="width: 100%; height: 100%;"></canvas>
    </div>
  </div>
  </div>

    <div class="row g-4 mb-4">
      <div class="col-md-6">
        <div class="card shadow-sm p-4">
          <div class="section-title">Top Produk</div>
          <ul class="list-group">
            <li class="list-group-item d-flex justify-content-between align-items-center">
              Royal Canin Adult <span class="badge bg-success">Rp 2.000.000</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              Makanan Kucing Me-O <span class="badge bg-success">Rp 1.800.000</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              Shampoo Anjing Pup Fresh <span class="badge bg-success">Rp 1.500.000</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              Mainan Kucing Bola Cakar <span class="badge bg-success">Rp 1.200.000</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              Kalung Anjing LED <span class="badge bg-success">Rp 1.050.000</span>
            </li>
          </ul>
        </div>
      </div>
    
      <div class="col-md-6">
        <div class="card shadow-sm p-4">
          <div class="section-title">Riwayat Pesanan Terakhir</div>
          <table class="table table-bordered">
            <thead class="table-light">
              <tr>
                <th>No</th>
                <th>Pelanggan</th>
                <th>Produk</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td>Andi</td>
                <td>Royal Canin Kitten</td>
                <td><span class="badge bg-warning text-dark">Diproses</span></td>
              </tr>
              <tr>
                <td>2</td>
                <td>Bella</td>
                <td>Kalung Kucing Lucu</td>
                <td><span class="badge bg-success">Selesai</span></td>
              </tr>
              <tr>
                <td>3</td>
                <td>Charlie</td>
                <td>Snack Anjing Beefy</td>
                <td><span class="badge bg-danger">Dibatalkan</span></td>
              </tr>
              <tr>
                <td>4</td>
                <td>Dina</td>
                <td>Vitamin Kucing Me-O</td>
                <td><span class="badge bg-success">Selesai</span></td>
              </tr>
              <tr>
                <td>5</td>
                <td>Erik</td>
                <td>Shampoo Anjing Herbal</td>
                <td><span class="badge bg-warning text-dark">Diproses</span></td>
              </tr>
              <tr>
                <td>6</td>
                <td>Fiona</td>
                <td>Mainan Kucing Laser</td>
                <td><span class="badge bg-success">Selesai</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
      </main>

  <footer>
    <div class="container text-center">
      <p>&copy; 2025 Petshop Kita. Semua Hak Dilindungi.</p>
    </div>
  </footer>

  <script>
    window.addEventListener('DOMContentLoaded', () => {
      new Chart(document.getElementById('salesChart'), {
        type: 'line',
        data: {
          labels: ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'],
          datasets: [{
            label: 'Penjualan (Rp)',
            data: [1500000, 2000000, 1800000, 2200000, 2500000, 1900000, 2100000],
            borderColor: '#f57c00',
            backgroundColor: 'rgba(245,124,0,0.2)',
            tension: 0.4,
            fill: true
          }]
        },
        options: {
          scales: {
            y: {
              beginAtZero: true,
              ticks: {
                callback: value => 'Rp ' + value.toLocaleString()
              }
            }
          }
        }
      });
  
      new Chart(document.getElementById('categoryChart'), {
        type: 'doughnut',
        data: {
          labels: ['Makanan Kucing', 'Makanan Anjing', 'Aksesoris', 'Vitamin'],
          datasets: [{
            label: 'Kategori',
            data: [45, 30, 15, 10],
            backgroundColor: ['#ffe0b2', '#ffccbc', '#b2dfdb', '#d1c4e9'],
          }]
        },
        options: {
          plugins: {
            legend: {
              position: 'bottom'
            }
          }
        }
      });
    });
  </script>
  
  </div>
  </div>
</body>
</html>
