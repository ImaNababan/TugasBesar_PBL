<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Manajemen Pesanan - Petshop</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Fredoka', sans-serif;
      background-color: #fffaf5;
    }
    header {
      background-color: #f6b26b;
      color: white;
      padding: 1rem;
    }
    .status-badge {
      padding: 6px 12px;
      border-radius: 20px;
      font-size: 0.85rem;
    }
    .status-pending { background-color: #fff3cd; color: #856404; }
    .status-proses { background-color: #cfe2ff; color: #084298; }
    .status-selesai { background-color: #d1e7dd; color: #0f5132; }
    .status-batal { background-color: #f8d7da; color: #842029; }
    .btn-cute {
      background-color: #f9c784;
      border: none;
      color: #fff;
      border-radius: 20px;
      padding: 8px 16px;
    }
    .btn-cute:hover {
      background-color: #f6b26b;
    }
  </style>
</head>
<body>

<header class="d-flex justify-content-between align-items-center">
  <h3><img src="assets/img/icons/paw.svg" width="40" class="me-2">Manajemen Pesanan</h3>
  <a href="dashboard.php" class="btn btn-light">Kembali ke Dashboard</a>
</header>

<div class="container my-4">
  <div class="d-flex justify-content-between mb-3 flex-wrap gap-2">
    <h5>Daftar Pesanan</h5>
    <input type="text" class="form-control" placeholder="Cari pelanggan..." style="max-width: 300px;">
  </div>

  <div class="table-responsive shadow-sm rounded">
    <table class="table align-middle table-bordered">
      <thead class="table-light">
        <tr>
          <th>No</th>
          <th>Nama Pelanggan</th>
          <th>Produk</th>
          <th>Tanggal</th>
          <th>Status</th>
          <th>Total</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td>Andi</td>
          <td>Royal Canin Kitten x2</td>
          <td>2025-04-08</td>
          <td><span class="status-badge status-pending">Menunggu</span></td>
          <td>Rp 500.000</td>
          <td>
            <button class="btn btn-sm btn-warning">Ubah</button>
            <button class="btn btn-sm btn-info text-white"><a href="detail.php"> Detail</a></button>
          </td>
        </tr>
        <tr>
          <td>2</td>
          <td>Bella</td>
          <td>Kalung Anjing Glow</td>
          <td>2025-04-07</td>
          <td><span class="status-badge status-proses">Diproses</span></td>
          <td>Rp 75.000</td>
          <td>
            <button class="btn btn-sm btn-warning">Ubah</button>
            <button class="btn btn-sm btn-info text-white">Detail</button>
          </td>
        </tr>
        <tr>
          <td>3</td>
          <td>Charlie</td>
          <td>Snack Anjing Daging</td>
          <td>2025-04-07</td>
          <td><span class="status-badge status-selesai">Selesai</span></td>
          <td>Rp 55.000</td>
          <td>
            <button class="btn btn-sm btn-warning">Ubah</button>
            <button class="btn btn-sm btn-info text-white">Detail</button>
          </td>
        </tr>
        <tr>
          <td>4</td>
          <td>Diana</td>
          <td>Vitamin B12 Kucing</td>
          <td>2025-04-06</td>
          <td><span class="status-badge status-batal">Dibatalkan</span></td>
          <td>Rp 35.000</td>
          <td>
            <button class="btn btn-sm btn-warning">Ubah</button>
            <button class="btn btn-sm btn-info text-white">Detail</button>
          </td>
        </tr>
        <tr>
          <td>5</td>
          <td>Eko</td>
          <td>Shampoo Anjing Pup Fresh x2</td>
          <td>2025-04-05</td>
          <td><span class="status-badge status-selesai">Selesai</span></td>
          <td>Rp 120.000</td>
          <td>
            <button class="btn btn-sm btn-warning">Ubah</button>
            <button class="btn btn-sm btn-info text-white">Detail</button>
          </td>
        </tr>
        <tr>
          <td>6</td>
          <td>Fitri</td>
          <td>Snack Kucing Tuna</td>
          <td>2025-04-05</td>
          <td><span class="status-badge status-proses">Diproses</span></td>
          <td>Rp 25.000</td>
          <td>
            <button class="btn btn-sm btn-warning">Ubah</button>
            <button class="btn btn-sm btn-info text-white">Detail</button>
          </td>
        </tr>
        <tr>
          <td>7</td>
          <td>Gilang</td>
          <td>Vitamin Anjing x3</td>
          <td>2025-04-04</td>
          <td><span class="status-badge status-pending">Menunggu</span></td>
          <td>Rp 105.000</td>
          <td>
            <button class="btn btn-sm btn-warning">Ubah</button>
            <button class="btn btn-sm btn-info text-white">Detail</button>
          </td>
        </tr>
        <tr>
          <td>8</td>
          <td>Hana</td>
          <td>Kandang Lipat Ukuran M</td>
          <td>2025-04-03</td>
          <td><span class="status-badge status-selesai">Selesai</span></td>
          <td>Rp 250.000</td>
          <td>
            <button class="btn btn-sm btn-warning">Ubah</button>
            <button class="btn btn-sm btn-info text-white">Detail</button>
          </td>
        </tr>
        <tr>
          <td>9</td>
          <td>Irwan</td>
          <td>Tempat Minum Anjing</td>
          <td>2025-04-03</td>
          <td><span class="status-badge status-batal">Dibatalkan</span></td>
          <td>Rp 45.000</td>
          <td>
            <button class="btn btn-sm btn-warning">Ubah</button>
            <button class="btn btn-sm btn-info text-white">Detail</button>
          </td>
        </tr>
        <tr>
          <td>10</td>
          <td>Jessica</td>
          <td>Pasir Wangi Kucing</td>
          <td>2025-04-02</td>
          <td><span class="status-badge status-proses">Diproses</span></td>
          <td>Rp 30.000</td>
          <td>
            <button class="btn btn-sm btn-warning">Ubah</button>
            <button class="btn btn-sm btn-info text-white">Detail</button>
          </td>
        </tr>
        <tr>
          <td>11</td>
          <td>Kiki</td>
          <td>Mainan Tikus Lucu</td>
          <td>2025-04-02</td>
          <td><span class="status-badge status-selesai">Selesai</span></td>
          <td>Rp 15.000</td>
          <td>
            <button class="btn btn-sm btn-warning">Ubah</button>
            <button class="btn btn-sm btn-info text-white">Detail</button>
          </td>
        </tr>
        <tr>
          <td>12</td>
          <td>Lutfi</td>
          <td>Royal Canin Adult x1</td>
          <td>2025-04-01</td>
          <td><span class="status-badge status-selesai">Selesai</span></td>
          <td>Rp 250.000</td>
          <td>
            <button class="btn btn-sm btn-warning">Ubah</button>
            <a href="detail.html" class="btn btn-sm btn-info text-white">Detail</a>
          </td>
        </tr>
      </tbody>
      
    </table>
  </div>
</div>

<footer class="text-center text-white py-3" style="background-color: #f6b26b;">
  &copy; 2025 Petshop Kita. Semua Hak Dilindungi.
</footer>

</body>
</html>
