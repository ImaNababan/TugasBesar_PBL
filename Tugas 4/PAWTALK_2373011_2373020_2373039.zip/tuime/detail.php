<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Detail Pesanan - Petshop Kita</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Fredoka', sans-serif;
      background-color: #fffaf5;
      color: #333;
    }
    header {
      background-color: #f6b26b;
      color: white;
      padding: 1rem;
    }
    .card {
      border-radius: 20px;
    }
    .section-title {
      font-size: 1.25rem;
      font-weight: 600;
      color: #f57c00;
      margin-bottom: 1rem;
    }
    .label {
      font-weight: bold;
      color: #555;
    }
    .value {
      color: #444;
    }
    .back-btn {
      background-color: #f9c784;
      color: white;
      border: none;
      border-radius: 20px;
      padding: 8px 16px;
    }
    .back-btn:hover {
      background-color: #f6b26b;
    }
  </style>
</head>
<body>

<header class="d-flex justify-content-between align-items-center">
  <h3><img src="assets/img/icons/box.webp" width="40" class="me-2">Detail Pesanan</h3>
  <a href="pesanan.php" class="back-btn">← Kembali</a>
</header>

<div class="container my-4">
  <div class="card p-4 shadow-sm">
    <div class="section-title">Informasi Umum</div>
    <div class="row mb-3">
      <div class="col-md-6">
        <p><span class="label">ID Transaksi:</span> <span class="value">TRX00123</span></p>
        <p><span class="label">Tanggal:</span> <span class="value">08 April 2025</span></p>
        <p><span class="label">Status:</span> <span class="badge bg-warning text-dark">Diproses</span></p>
      </div>
      <div class="col-md-6">
        <p><span class="label">Nama Pelanggan:</span> <span class="value">Siti Nurhaliza</span></p>
        <p><span class="label">Username:</span> <span class="value">sitinurhaliza88</span></p>
        <p><span class="label">Alamat Pengiriman:</span> <span class="value">Jl. Mawar No. 123, Bandung</span></p>
        <p><span class="label">No. Telepon:</span> <span class="value">0812-3456-7890</span></p>
      </div>      
    </div>

    <div class="section-title">Daftar Produk</div>
    <table class="table table-bordered align-middle">
      <thead class="table-light">
        <tr>
          <th>ID Produk</th>
          <th>Nama Produk</th>
          <th>Jumlah</th>
          <th>Harga Satuan</th>
          <th>Subtotal</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>PRD001</td>
          <td>Royal Canin Kitten</td>
          <td>2</td>
          <td>Rp 250.000</td>
          <td>Rp 500.000</td>
        </tr>
        <tr>
          <td>PRD002</td>
          <td>Snack Anjing Rasa Daging</td>
          <td>3</td>
          <td>Rp 55.000</td>
          <td>Rp 165.000</td>
        </tr>
      </tbody>
    </table>

    <div class="text-end mt-3">
      <p><strong>Total Pembayaran:</strong> Rp 665.000</p>
    </div>
  </div>
</div>

<footer class="text-center text-white py-3" style="background-color: #f6b26b;">
  &copy; 2025 Petshop Kita. Semua Hak Dilindungi.
</footer>

</body>
</html>
